﻿namespace UGFExtensions
{
    public enum AssetType
    {
        None,
        Text,
        Folder,
    }
}