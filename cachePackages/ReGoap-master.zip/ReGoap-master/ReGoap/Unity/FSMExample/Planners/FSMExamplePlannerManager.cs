﻿namespace ReGoap.Unity.FSMExample.Planners
{
    public class FSMExamplePlannerManager : ReGoapPlannerManager<string, object>
    {
    }
}
