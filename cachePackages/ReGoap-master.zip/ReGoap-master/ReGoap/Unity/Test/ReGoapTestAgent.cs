﻿namespace ReGoap.Unity.Test
{
    public class ReGoapTestAgent : ReGoapAgent<string, object>
    {
        public void Init()
        {
            Awake();
        }
    }
}