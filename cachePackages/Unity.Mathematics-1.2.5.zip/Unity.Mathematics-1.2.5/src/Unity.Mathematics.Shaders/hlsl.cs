using System.Runtime.CompilerServices;

namespace Unity.Mathematics.Shaders
{
    public static class hlsl
    {
        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float ddx(float x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2 ddx(float2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3 ddx(float3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4 ddx(float4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2x2 ddx(float2x2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3x3 ddx(float3x3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4x4 ddx(float4x4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float ddx_fine(float x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2 ddx_fine(float2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3 ddx_fine(float3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4 ddx_fine(float4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2x2 ddx_fine(float2x2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3x3 ddx_fine(float3x3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4x4 ddx_fine(float4x4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float ddx_coarse(float x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2 ddx_coarse(float2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3 ddx_coarse(float3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4 ddx_coarse(float4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2x2 ddx_coarse(float2x2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3x3 ddx_coarse(float3x3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4x4 ddx_coarse(float4x4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float ddy(float x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2 ddy(float2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3 ddy(float3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4 ddy(float4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2x2 ddy(float2x2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3x3 ddy(float3x3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4x4 ddy(float4x4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float ddy_fine(float x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2 ddy_fine(float2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3 ddy_fine(float3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4 ddy_fine(float4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2x2 ddy_fine(float2x2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3x3 ddy_fine(float3x3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4x4 ddy_fine(float4x4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float ddy_coarse(float x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2 ddy_coarse(float2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3 ddy_coarse(float3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4 ddy_coarse(float4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float2x2 ddy_coarse(float2x2 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3x3 ddy_coarse(float3x3 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float4x4 ddy_coarse(float4x4 x) { throw new System.NotImplementedException(); }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static void discard() { }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static void clip(float i) { }

        [MethodImpl((MethodImplOptions)0x100)] // agressive inline
        public static float3 faceforward(float3 n, float3 i, float3 ng) { return math.cross(-n, math.sign(math.dot(i, ng))); }
    }
}
